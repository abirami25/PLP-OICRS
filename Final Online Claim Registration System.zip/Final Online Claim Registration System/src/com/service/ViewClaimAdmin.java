package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.Commonconnection;

public class ViewClaimAdmin extends HttpServlet {
public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{

	Connection con=null;
	 con=Commonconnection.getCon();
	String str=null;
	
	PreparedStatement ps2= null;
		RequestDispatcher rd=null;
	
		String no=req.getParameter("user1");
		
		ResultSet rs2=null;
		HttpSession session5=req.getSession(true);
		session5.setAttribute("un", no);
		
		try {
			ps2=con.prepareStatement("select rolecode from userrole where username=?");
			  ps2.setString(1, no);
			  System.out.println(no);
			    rs2=ps2.executeQuery();
			    while(rs2.next()) {
			    	 str=rs2.getString(1);
			    	
			    	System.out.println(str);
			    }
			    if("Insured".equals(str)) {
			    rd=req.getRequestDispatcher("/viewclaim1.jsp");
			    rd.forward(req, res);
			    }
			    else {
			    	rd=req.getRequestDispatcher("/Failviewclaimadmin.jsp");
					rd.forward(req, res);
			    }
		}
catch (SQLException e) {
			
			e.printStackTrace();
		} 
}}

	