CREATE TABLE userrole(
username varchar2(20) primary key,
password varchar2(12),
 ROLECODE  VARCHAR2(20),
  AGENTCODE  VARCHAR2(10)
);


CREATE TABLE claim(
CLAIMNUMBER NUMBER(10) primary key,
 CLAIMREASON  VARCHAR2(30),
 ACCIDENTLOCATIONSTREET                             VARCHAR2(40)
 ACCIDENTCITY                                       VARCHAR2(15)
 ACCIDENTSTATE                                      VARCHAR2(15)
 ACCIDENTZIP                                        NUMBER(5)
 CLAIMTYPE                                          VARCHAR2(30)
 POLICYNUMBER                                       NUMBER(10)


);

CREATE TABLE viewclaim(
USERNAME                                           VARCHAR2(20)
 POLICYNUMBER                                       NUMBER(10)
 CLAIMTYPE                                          VARCHAR2(15)
 CLAIMNUMBER                                        NUMBER(15)

);

CREATE TABLE policydetails(

 POLICYNUMBER                                       NUMBER(10)
 QUESTIONID                                         VARCHAR2(100)
 ANSWER                                             VARCHAR2(10)

);

CREATE SEQUENCE claimnumber_seq
START WITH 100;

CREATE SEQUENCE policynumber_seq
START WITH 1000;