package com.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.bean.Userbean;

class Testuser {

	@Test
	void testSetUserName() {
		Userbean obj=new Userbean();
		obj.setUserName("Yeshwanth");
		assertEquals("Yeshwanth",obj.getUserName());
	}
	@Test
	void testSetPassWord() {
		Userbean obj=new Userbean();
		obj.setPassWord("Yeshu123");
		assertEquals("Yeshu123",obj.getPassWord());
	}
	@Test
	void testsetRoleCode() {
		Userbean obj=new Userbean();
		obj.setRoleCode("Claim Adjuster");
		assertEquals("Claim Adjuster",obj.getRoleCode());
	}
	@Test
	void testsetAgent() {
		Userbean obj=new Userbean();
		obj.setAgent("null");
		assertEquals("null",obj.getAgent());
	}
}